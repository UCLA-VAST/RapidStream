#include "stdio.h"
#include "stdlib.h"
#include "math.h"

typedef float data_t;
//#define I 1040
#define I 208
#define J 896
//#define J 1152
#define K 256
//#define I 256
//#define J 256
//#define K 256
