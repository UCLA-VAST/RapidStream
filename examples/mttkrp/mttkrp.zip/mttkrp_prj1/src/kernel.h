#include "stdio.h"
#include "stdlib.h"
#include "math.h"

typedef float data_t;
#define I 256 
#define J 256 
#define K 256 
#define L 256 
