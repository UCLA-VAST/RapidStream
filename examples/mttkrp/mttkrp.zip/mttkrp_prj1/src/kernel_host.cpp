#include <assert.h>
#include <stdio.h>
#include "kernel_kernel.h"

/*
 * This code implements the Matricized Tensor Times Khatri-Rao Product (MTTKRP), which performs:
 * D(i,j) += A(i,k,l) * B(k,j) * C(l,j)
 * Input: A[I][K][L], B[K][J], C[L][J]
 * Output: D[I][J]
 */

#include "kernel.h"

int main(int argc, char **argv){
  // declarations
  static data_t A[I][K][L];
  static data_t B[K][J];
//  static data_t C[L][J];
  static data_t C[J][L];
  static data_t D[I][J];
  static data_t D_golden[I][J];

  // data initialization
  for (int i = 0; i < I; i++)
    for (int k = 0; k < K; k++) 
      for (int l = 0; l < L; l++) {
        A[i][k][l] = 2.5;
      }
  for (int k = 0; k < K; k++)
    for (int j = 0; j < J; j++) {
      B[k][j] = 2.5;
    }
  for (int l = 0; l < L; l++)
    for (int j = 0; j < J; j++) {
//      C[l][j] = 2.5;
      C[j][l] = 2.5;
    }
  data_t tmp;

  // computation
  {
    // Allocate memory in host memory
    float *dev_A_unserialized = (float *)malloc((256) * (256) * (256) * sizeof(float));
    float *dev_A = (float *)malloc(33554432 * sizeof(float));
    float *dev_B_unserialized = (float *)malloc((256) * (256) * sizeof(float));
    float *dev_B = (float *)malloc(131072 * sizeof(float));
    float *dev_C_unserialized = (float *)malloc((256) * (256) * sizeof(float));
    float *dev_C = (float *)malloc(16777216 * sizeof(float));
    float *dev_D_unserialized = (float *)malloc((256) * (256) * sizeof(float));
    float *dev_D = (float *)malloc(65536 * sizeof(float));

    // Initialize host buffers
    memcpy(dev_A_unserialized, A, (256) * (256) * (256) * sizeof(float));
    memcpy(dev_B_unserialized, B, (256) * (256) * sizeof(float));
    memcpy(dev_C_unserialized, C, (256) * (256) * sizeof(float));
    memcpy(dev_D_unserialized, D, (256) * (256) * sizeof(float));
    host_serialize_A(dev_A, dev_A_unserialized);
    host_serialize_B(dev_B, dev_B_unserialized);
    host_serialize_C(dev_C, dev_C_unserialized);

    // Allocate buffers in device memory
    std::vector<A_t16 *> buffer_A;
    std::vector<B_t16 *> buffer_B;
    std::vector<C_t16 *> buffer_C;
    std::vector<D_t16 *> buffer_D;
    for (int i = 0; i < 1; i++) {
      A_t16 *buffer_A_tmp = (A_t16 *)malloc((33554432) * sizeof(float));
      buffer_A.push_back(buffer_A_tmp);
    }
    for (int i = 0; i < 1; i++) {
      B_t16 *buffer_B_tmp = (B_t16 *)malloc((131072) * sizeof(float));
      buffer_B.push_back(buffer_B_tmp);
    }
    for (int i = 0; i < 1; i++) {
      C_t16 *buffer_C_tmp = (C_t16 *)malloc((16777216) * sizeof(float));
      buffer_C.push_back(buffer_C_tmp);
    }
    for (int i = 0; i < 1; i++) {
      D_t16 *buffer_D_tmp = (D_t16 *)malloc((65536) * sizeof(float));
      buffer_D.push_back(buffer_D_tmp);
    }

    for (int i = 0; i < 1; i++) {
      memcpy(buffer_A[i], dev_A, (33554432) * sizeof(float));
    }

    for (int i = 0; i < 1; i++) {
      memcpy(buffer_B[i], dev_B, (131072) * sizeof(float));
    }

    for (int i = 0; i < 1; i++) {
      memcpy(buffer_C[i], dev_C, (16777216) * sizeof(float));
    }

    {
      // Launch the kernel
      kernel0(buffer_A[0], buffer_B[0], buffer_C[0], buffer_D[0]);
    }
    for (int i = 0; i < 1; i++) {
      memcpy(dev_D, buffer_D[i], (65536) * sizeof(float));
    }

    host_deserialize_D(dev_D_unserialized, dev_D);
    // Restore data from host buffers
    memcpy(D, dev_D_unserialized, (256) * (256) * sizeof(float));

    // Clean up resources
    for (int i = 0; i < 1; i++) {
      free(buffer_A[i]);
    }
    for (int i = 0; i < 1; i++) {
      free(buffer_B[i]);
    }
    for (int i = 0; i < 1; i++) {
      free(buffer_C[i]);
    }
    for (int i = 0; i < 1; i++) {
      free(buffer_D[i]);
    }
    free(dev_A);
    free(dev_A_unserialized);
    free(dev_B);
    free(dev_B_unserialized);
    free(dev_C);
    free(dev_C_unserialized);
    free(dev_D);
    free(dev_D_unserialized);
  }

  for (int i = 0; i < I; i++)
    for (int j = 0; j < J; j++) {
      D_golden[i][j] = 0;
      for (int k = 0; k < K; k++) {
//        for (int l = 0; l < L; l++) {
//          D_golden[i][j] += A[i][k][l] * B[k][j] * C[l][j];
//        }
        data_t tmp = 0;
        for (int l = 0; l < L; l++) {
//          tmp += A[i][k][l] * C[l][j];
          tmp += A[i][k][l] * C[j][l];
        }
        D_golden[i][j] += B[k][j] * tmp;
      }
    }

  // comparison
  int err = 0;
  float thres = 0.01;
  for (int i = 0; i < I; i++) 
    for (int j = 0; j < J; j++) {
      if (fabs((float)D_golden[i][j] - (float)D[i][j]) > thres) {
        err++;
      }
    }

  if (err) {
    printf("Test failed with %d errors!\n", err);
    return -1;
  } else {
    printf("Test passed!\n");
    return 0;
  }
}
